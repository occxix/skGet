# Qcli-Skills (qskills)

一款面向个人开发者的 CLI 技能管理工具，支持公共技能、私人技能和知识库的统一管理与多源同步。

## 特性

- **一站式管理** - 将分散的技能脚本、代码片段、知识笔记统一管理
- **多源同步** - 通过 Git 仓库实现公共资源与私人资源的分类同步
- **即取即用** - 通过 npx 一键调用，无需全局安装
- **安全可控** - 敏感信息检测机制，防止意外泄露
- **跨平台** - 支持 Windows、macOS、Linux

## 快速开始

### 使用 npx（推荐）

无需安装，直接使用：

```bash
# 查看帮助
npx qskills --help

# 初始化配置
npx qskills config init

# 添加技能
npx qskills skill add ./my-script.js --name my-script

# 列出所有技能
npx qskills skill list

# 同步到远程仓库
npx qskills sync
```

### 全局安装

```bash
npm install -g qskills

# 然后可以直接使用
qskills --help
qskills skill list
```

### 从 GitHub 直接使用

```bash
# 使用最新版本
npx github:your-username/qskills skill list

# 指定版本/分支
npx github:your-username/qskills#v1.0.0 skill list
npx github:your-username/qskills#main skill add ./my-skill
```

## 安装要求

- Node.js 16.0.0 或更高版本
- npm 8.0.0 或更高版本

## 命令详解

### 技能管理 (skill)

#### 添加技能

```bash
# 添加单文件技能
npx qskills skill add ./script.js --name my-script

# 添加文件夹技能
npx qskills skill add ./my-project --name my-project --type folder

# 指定来源和标签
npx qskills skill add ./tool.py \
  --name my-tool \
  --source private \
  --tags python,automation,tool \
  --description "A useful automation tool"

# 跳过安全扫描（需确认）
npx qskills skill add ./config.json --name my-config --skip-scan
```

**参数说明：**

| 参数 | 简写 | 说明 | 默认值 |
|------|------|------|--------|
| `--name` | `-n` | 技能名称 | 必填 |
| `--type` | `-t` | 类型：single 或 folder | single |
| `--source` | `-s` | 来源：public 或 private | private |
| `--tags` | | 标签（逗号分隔） | |
| `--description` | | 描述 | |
| `--skip-scan` | | 跳过安全扫描 | false |

#### 列出技能

```bash
# 列出所有技能
npx qskills skill list

# 按来源筛选
npx qskills skill list --source public

# 按标签筛选
npx qskills skill list --tags python,automation

# JSON 格式输出
npx qskills skill list --json
```

#### 搜索技能

```bash
# 按关键词搜索
npx qskills skill search python

# 按标签搜索
npx qskills skill search api --tags automation
```

#### 删除技能

```bash
# 删除技能（需确认）
npx qskills skill remove my-script

# 强制删除
npx qskills skill remove my-script --force

# 指定来源删除
npx qskills skill remove my-script --source private
```

#### 同步技能

```bash
# 同步所有仓库
npx qskills skill sync

# 同步指定来源
npx qskills skill sync --source public

# 强制覆盖本地
npx qskills skill sync --force
```

### 知识库管理 (knowledge)

#### 添加知识条目

```bash
# 添加文档
npx qskills knowledge add ./article.md \
  --title "API 设计指南" \
  --type document \
  --category api \
  --tags api,design

# 添加代码片段
npx qskills knowledge add ./snippet.js \
  --title "工具函数集合" \
  --type code-snippet \
  --category utils \
  --tags javascript,utils

# 添加模板
npx qskills knowledge add ./template/ \
  --title "React 项目模板" \
  --type template \
  --category frontend \
  --tags react,template
```

**知识类型：**

| 类型 | 说明 |
|------|------|
| `document` | 文档、笔记 |
| `code-snippet` | 代码片段 |
| `template` | 项目模板 |
| `note` | 快速笔记 |

#### 列出知识条目

```bash
# 列出所有
npx qskills knowledge list

# 按类型筛选
npx qskills knowledge list --type code-snippet

# 按分类筛选
npx qskills knowledge list --category api

# JSON 输出
npx qskills knowledge list --json
```

#### 搜索知识条目

```bash
npx qskills knowledge search "API" --category backend
```

#### 删除知识条目

```bash
npx qskills knowledge remove <id>
```

### 配置管理 (config)

#### 初始化配置

```bash
# 交互式初始化
npx qskills config init
```

初始化过程会引导你完成：
1. 配置存储路径
2. 配置 Git 仓库（可选）
3. 权限和安全设置

#### 查看配置

```bash
# 列出所有配置
npx qskills config list

# 获取单个配置项
npx qskills config get storage.baseDir

# JSON 输出
npx qskills config list --json
```

#### 修改配置

```bash
# 设置配置项
npx qskills config set storage.baseDir ~/.my-skills

# 启用自动同步
npx qskills config set sync.autoSync true

# 配置远程仓库
npx qskills config set remotes.public.url https://github.com/user/public-skills.git
```

### 同步命令 (sync)

```bash
# 同步所有仓库
npx qskills sync

# 同步指定来源
npx qskills sync --source private

# 预览变更（不实际同步）
npx qskills sync --dry-run

# 强制覆盖
npx qskills sync --force
```

## 安全功能

### 敏感信息扫描

添加技能时自动扫描以下敏感信息：

| 类型 | 说明 |
|------|------|
| AWS Access Key | AKIA 开头的密钥 |
| GitHub Token | ghp_/gho_/ghu_/ghs_ 开头的令牌 |
| 私钥文件 | PEM 格式私钥 |
| API Key | api_key/secret_key 等模式 |
| JWT Token | eyJ 开头的 JWT |
| 数据库 URL | 包含密码的连接字符串 |
| Slack Token | xox 开头的 Slack 令牌 |

### 扫描示例

```bash
# 正常添加（自动扫描）
npx qskills skill add ./config.js --name my-config

# 发现敏感信息时会提示
# ⚠️  Sensitive information detected:
#   [HIGH] aws-access-key in config.js:10
#   [MED] api-key-generic in config.js:15

# 确认后可继续或取消
```

### 跳过扫描

```bash
# 明确跳过（需二次确认）
npx qskills skill add ./public-config.json --name public-config --skip-scan
```

## 配置文件

配置文件位于 `~/.qcli/config.json`：

```json
{
  "version": "1.0.0",
  "initialized": true,
  "storage": {
    "baseDir": "~/.qcli/data",
    "skillsDir": "skills",
    "knowledgeDir": "knowledge"
  },
  "remotes": {
    "public": {
      "url": "https://github.com/user/public-skills.git",
      "branch": "main",
      "enabled": true
    },
    "private": {
      "url": "git@github.com:user/private-skills.git",
      "branch": "main",
      "enabled": true
    }
  },
  "sync": {
    "autoSync": false,
    "syncInterval": 0,
    "confirmBeforeSync": true
  },
  "scanner": {
    "enabled": true,
    "skipPatterns": ["*.md", "docs/**"]
  },
  "security": {
    "scanBeforePush": true,
    "warnPublicRepo": true
  }
}
```

## Git 认证

### 使用 Personal Access Token

```bash
# 设置环境变量
export QSKILLS_TOKEN=ghp_your_token_here

# 或在 Windows CMD
set QSKILLS_TOKEN=ghp_your_token_here

# 或在 Windows PowerShell
$env:QSKILLS_TOKEN="ghp_your_token_here"
```

### 创建 GitHub Token

1. 访问 GitHub Settings → Developer settings → Personal access tokens
2. 创建新 Token，勾选 `repo` 权限
3. 复制 Token 并设置环境变量

## 存储结构

```
~/.qcli/
├── config.json              # 配置文件
├── data/
│   ├── index.json           # 本地索引
│   ├── skills/
│   │   ├── public/          # 公共技能
│   │   │   └── skill-name/
│   │   │       ├── skill.json
│   │   │       └── ...
│   │   └── private/         # 私人技能
│   │       └── skill-name/
│   │           ├── skill.json
│   │           └── ...
│   └── knowledge/
│       ├── public/
│       └── private/
├── public-repo/             # 公共仓库克隆
└── private-repo/            # 私人仓库克隆
```

## 开发

### 克隆与构建

```bash
git clone https://github.com/your-username/qskills.git
cd qskills

# 安装依赖
npm install

# 构建
npm run build

# 测试
npm test

# 本地运行
node bin/qskills.js --help
```

### 开发脚本

```bash
# 使用开发脚本（推荐）
./docs/scripts/dev-start.sh    # Linux/macOS
docs\scripts\dev-start.bat     # Windows

# 或手动执行
npm run dev           # 监听模式编译
npm run test:watch    # 监听模式测试
```

### 运行测试

```bash
npm test                    # 运行所有测试
npm run test:watch          # 监听模式
npm run test:coverage       # 生成覆盖率报告
```

## 发布

### 发布到 npm

```bash
# 1. 登录 npm
npm login

# 2. 检查发布内容
npm pack --dry-run

# 3. 发布
npm publish

# 4. 发布 beta 版本
npm publish --tag beta
```

### 版本管理

```bash
npm version patch    # 1.0.0 -> 1.0.1
npm version minor    # 1.0.0 -> 1.1.0
npm version major    # 1.0.0 -> 2.0.0
```

## 常见问题

### Q: npx 提示找不到命令？

确保使用 Node.js 16+：
```bash
node -v  # 应该 >= 16.0.0
```

### Q: 同步失败，提示认证错误？

设置 GitHub Token：
```bash
export QSKILLS_TOKEN=your_token
```

### Q: 如何修改默认存储路径？

```bash
npx qskills config set storage.baseDir ~/custom-path
```

### Q: 如何查看详细日志？

命令添加 `--verbose` 参数（开发中）

### Q: Windows 下路径问题？

使用正斜杠或双反斜杠：
```bash
npx qskills skill add "./scripts/tool.js"
# 或
npx qskills skill add ".\\scripts\\tool.js"
```

## 贡献

欢迎提交 Issue 和 Pull Request！

1. Fork 本仓库
2. 创建功能分支：`git checkout -b feature/my-feature`
3. 提交更改：`git commit -am 'Add my feature'`
4. 推送分支：`git push origin feature/my-feature`
5. 创建 Pull Request

## 许可证

[MIT](LICENSE)

## 相关链接

- [产品需求文档 (PRD)](docs/PRD_Qcli-Skills_20260409.md)
- [技术规格文档](docs/TECH_SPEC_Qcli-Skills_20260409.md)
- [验收测试报告](docs/ACCEPTANCE_TEST_REPORT.md)
- [脚本说明](docs/scripts/README.md)
